Cenários de front foram construídos utilizando cucumber+capybara, para executar basta configurar previamente o ruby e o bundler e através do terminal executar o comando 'cucumber' ou 'cucumber -t "tag do cenario desejado"

Cenário de API foi feito utilizando HTTParty + rspec, para executar o mesmo basta configurar previamente o ruby e o bundler e através do terminal executar o comando 'rspec"